npm install react-scripts -g
npm start